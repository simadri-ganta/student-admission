package business_logic;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;

public class status_check {

	@SuppressWarnings("unchecked")
	public void check(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		try {
		ArrayList<String> details=new ArrayList<>();
		details.add(req.getParameter("name"));
		String value=req.getParameter("password");
		String[] values = value.split("/",4);
		System.out.println(values[0]+values[1]+values[2]+values[3]);
		details.add(values[0]);
		details.add(values[1]);
		details.add(values[3]);
		System.out.println(req.getParameter("name")+" "+Arrays.toString(values));
		ArrayList<String> status=ClientBuilder.newClient()
		.target("http://localhost:8082/student-admission/webapi/status_checking")
		.request(MediaType.APPLICATION_JSON)
		.post(Entity.entity(details, MediaType.APPLICATION_JSON))
		.readEntity(ArrayList.class);
		switch(status.get(0)) {
		case "accepted":
			resp.getWriter().print("accepted");
			break;
		case "rejected":
			System.out.println("all list"+status);
			req.getSession().setAttribute("list",status);
			req.getRequestDispatcher("status.jsp").forward(req, resp);
			break;
		case "password_wrong":
			resp.getWriter().print("password wrong");
			break;
		case "user_not_avail":
			resp.getWriter().print("invalid user");
			
			break;
			
		}
		}catch(NumberFormatException num) {
			resp.getWriter().print("enter correct format");
		}catch(ArrayIndexOutOfBoundsException num1) {
			resp.getWriter().print("enter correct format");
		}
		
	}

}
