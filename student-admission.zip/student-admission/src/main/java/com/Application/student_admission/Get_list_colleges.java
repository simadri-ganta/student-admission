package com.Application.student_admission;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("getting_list")

public class Get_list_colleges {
	@SuppressWarnings("unused")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<String> getPost(ArrayList<String> login_detals) throws IOException, ServletException {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("StudentPU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		ArrayList<String> list = new ArrayList<String>();
		@SuppressWarnings("unchecked")
		List<Object> resultlist = em.createNativeQuery("select * from Number_of_colleges;").getResultList();
		for (int i = 1; i < resultlist.size(); i++) {
			Object[] row = (Object[]) resultlist.get(i);
			list.add(list.size(), (String) row[0]);
			list.add(list.size(), (String) row[1]);
		}
		System.out.println(list);
		return list;

	}
}