package business_logic;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
@SuppressWarnings("rawtypes")
public class Depart_count {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("StudentPU");
	EntityManager em=emf.createEntityManager();

	public BigInteger cse(String code) {
		List resultlist=em.createNativeQuery("select count(*) from Selected_students where alloted_department='cse' and college_code="+(char)34+code+(char)34+";").getResultList();
		BigInteger value=(BigInteger) resultlist.get(0);
		System.out.println(value.intValue());
		return value;
		
	}

	public BigInteger ece(String code) {
		List resultlist=em.createNativeQuery("select count(*) from Selected_students where alloted_department='ece' and college_code="+(char)34+code+(char)34+";").getResultList();
		BigInteger value=(BigInteger) resultlist.get(0);
		System.out.println(value.intValue());
		return value;	
		}

	public BigInteger it(String code) {
		List resultlist=em.createNativeQuery("select count(*) from Selected_students where alloted_department='it' and college_code="+(char)34+code+(char)34+";").getResultList();
		BigInteger value=(BigInteger) resultlist.get(0);
		System.out.println(value.intValue());
		return value;
	}

	public BigInteger mech(String code) {
		List resultlist=em.createNativeQuery("select count(*) from Selected_students where alloted_department='mech' and college_code="+(char)34+code+(char)34+";").getResultList();
		BigInteger value=(BigInteger) resultlist.get(0);
		System.out.println(value.intValue());
		return value;
	}

}
