package com.Application.student_admission;

import java.util.ArrayList;
import java.util.Iterator;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import entity_bean_classes.Registration_table;

public class Update_status {

	public void update(ArrayList<String> accepted, ArrayList<String> rejected) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("StudentPU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Iterator<String> accept = accepted.iterator();
		Iterator<String> reject = rejected.iterator();
		while (accept.hasNext()) {
			em.find(Registration_table.class, accept.next()).setStatus_application("accepted");
//			em.createNativeQuery("update Registration_table set Status_application=" + (char) 34 + "accepted" + (char) 34
//					+ " where name=" + (char) 34 + accept.next() + (char) 34 + ";").executeUpdate();
		}
		while (reject.hasNext()) {
			em.find(Registration_table.class, reject.next()).setStatus_application("Rejected");
		}

		em.getTransaction().commit();

	}

}
