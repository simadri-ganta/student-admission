package com.Application.student_admission;

import java.io.IOException;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import entity_bean_classes.Registration_table;

@Path("another_time")

public class Another_time {
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<String> getPost(ArrayList<String> list) throws IOException {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("StudentPU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.remove(em.find(Registration_table.class, list.get(0)));
		em.getTransaction().commit();
		return list;
	
	}
}
