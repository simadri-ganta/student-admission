package com.Application.student_admission;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import business_logic.Depart_count;

public class available_seats_colleges {

	@SuppressWarnings("unchecked")
	public ArrayList<String> getlist(ArrayList<String> setlist) {
		Depart_count count = new Depart_count();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("StudentPU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<Object> list = em.createNativeQuery("select college_name,college_code from Number_of_colleges;")
				.getResultList();
		for (int i=1;i<list.size();i++) {
			Object[] av = (Object[]) list.get(i);
			setlist.add((String) av[0]);
			BigInteger cse = count.cse((String) av[1]);
			BigInteger ece = count.ece((String) av[1]);
			BigInteger it = count.it((String) av[1]);
			BigInteger mech = count.mech((String) av[1]);
			setlist.add(cse.toString());
			setlist.add(ece.toString());
			setlist.add(it.toString());
			setlist.add(mech.toString());
			System.out.println(cse+""+ece+""+it+""+mech);

		}

		return setlist;
	}

}
