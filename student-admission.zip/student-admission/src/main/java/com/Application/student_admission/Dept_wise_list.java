package com.Application.student_admission;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

@SuppressWarnings("unchecked")
public class Dept_wise_list {

	public ArrayList<String> get_list(String college_code) {
		ArrayList<String> list = new ArrayList<String>();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("StudentPU");
		EntityManager em = emf.createEntityManager();
		list.add("/");
		List<Object> list1 = em
				.createNativeQuery("select * from Selected_students where alloted_department='cse' and college_code="
						+ (char) 34 + college_code + (char) 34 + ";")
				.getResultList();
		Iterator<Object> iterate1 = list1.iterator();
		while (iterate1.hasNext()) {
			Object[] rows = (Object[]) iterate1.next();
			System.out.println(Arrays.toString(rows));
			list.add(rows[0].toString() + ", " + // name
					rows[1].toString() + ", " + // alloted_department
					rows[2].toString() + ", " + // college_name
					rows[3].toString() + ", " + // department
					rows[4].toString() + ", " + // gpa
					rows[5].toString() + ", " + // joined_date
					rows[6].toString() + ", " + // marks
					rows[7].toString() + ", " + // percentage
					rows[8].toString() + ", " + // school
					rows[9].toString());
		}
		list.add("/");
		List<Object> list2 = em
				.createNativeQuery("select * from Selected_students where alloted_department='ece' and college_code="
						+ (char) 34 + college_code + (char) 34 + ";")
				.getResultList();
		Iterator<Object> iterate2 = list2.iterator();
		while (iterate2.hasNext()) {
			Object[] rows = (Object[]) iterate2.next();
			System.out.println(Arrays.toString(rows));
			list.add(rows[0].toString() + ", " + // name
					rows[1].toString() + ", " + // alloted_department
					rows[2].toString() + ", " + // college_name
					rows[3].toString() + ", " + // department
					rows[4].toString() + ", " + // gpa
					rows[5].toString() + ", " + // joined_date
					rows[6].toString() + ", " + // marks
					rows[7].toString() + ", " + // percentage
					rows[8].toString() + ", " + // school
					rows[9].toString());
		}
		list.add("/");
		List<Object> list3 = em
				.createNativeQuery("select * from Selected_students where alloted_department='it' and college_code="
						+ (char) 34 + college_code + (char) 34 + ";")
				.getResultList();
		Iterator<Object> iterate3 = list3.iterator();
		while (iterate3.hasNext()) {
			Object[] rows = (Object[]) iterate3.next();
			System.out.println(Arrays.toString(rows));
			list.add(rows[0].toString() + ", " + // name
					rows[1].toString() + ", " + // alloted_department
					rows[2].toString() + ", " + // college_name
					rows[3].toString() + ", " + // department
					rows[4].toString() + ", " + // gpa
					rows[5].toString() + ", " + // joined_date
					rows[6].toString() + ", " + // marks
					rows[7].toString() + ", " + // percentage
					rows[8].toString() + ", " + // school
					rows[9].toString());
		}

		list.add("/");
		List<Object> list4 = em
				.createNativeQuery("select * from Selected_students where alloted_department='mech' and college_code="
						+ (char) 34 + college_code + (char) 34 + ";")
				.getResultList();
		Iterator<Object> iterate4 = list4.iterator();
		while (iterate4.hasNext()) {
			Object[] rows = (Object[]) iterate4.next();
			System.out.println(Arrays.toString(rows));
			list.add(rows[0].toString() + ", " + // name
					rows[1].toString() + ", " + // alloted_department
					rows[2].toString() + ", " + // college_name
					rows[3].toString() + ", " + // department
					rows[4].toString() + ", " + // gpa
					rows[5].toString() + ", " + // joined_date
					rows[6].toString() + ", " + // marks
					rows[7].toString() + ", " + // percentage
					rows[8].toString() + ", " + // school
					rows[9].toString());
		}
		System.out.println(list);
		return list;
	}

}
