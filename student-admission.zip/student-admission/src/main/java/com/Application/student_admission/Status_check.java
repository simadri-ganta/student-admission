package com.Application.student_admission;

import java.io.IOException;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import business_logic.Depart_count;
import entity_bean_classes.Registration_table;

@Path("status_checking")

public class Status_check {
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<String> getPost(ArrayList<String> list) throws IOException {

		String name = list.get(0);
		String board = list.get(1);
		String gpa = list.get(2);
		String percentage = list.get(3);
		ArrayList<String> response_list = new ArrayList<String>();

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("StudentPU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Registration_table student = em.find(Registration_table.class, name);
		if (student != null) {
			if (student.getBoard().equals(board) && student.getGpa().equals(gpa)
					&& student.getPercentage() == Integer.valueOf(percentage)) {
				switch(student.getStatus_application()) {
				case "pending...":
					response_list.add("pending");
					break;
				case "accepted":
					response_list.add("accepted");
					break;
				case "rejected":
					response_list.add("rejected");
					new available_seats_colleges().getlist(response_list);
					break;
					
				}
				
			}else {
				response_list.add("password_wrong");
			}

		} else {
			response_list.add("user_not_avail");

		}
		System.out.println(response_list);

		return response_list;

	}
}
