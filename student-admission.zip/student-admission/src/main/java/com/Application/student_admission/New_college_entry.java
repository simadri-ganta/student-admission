package com.Application.student_admission;

import java.io.IOException;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import entity_bean_classes.Admin_table;
import entity_bean_classes.Number_of_colleges;

@Path("new_college_entry")

public class New_college_entry {
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public ArrayList<String> getPost(ArrayList<String> list) throws IOException {
		Number_of_colleges newentry = new Number_of_colleges();

		newentry.setCollege_name(list.get(0));
		newentry.setCollege_code(list.get(1));
		newentry.setCollege_rank(list.get(2));
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("StudentPU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(newentry);
		
		
		Admin_table admin_creation=new Admin_table();
		admin_creation.setId(list.get(0)+list.get(1));
		admin_creation.setPass(list.get(2)+list.get(1)+list.get(0));
		admin_creation.setAdmin(newentry);
		em.persist(admin_creation);
		em.getTransaction().commit();
		
		ArrayList<String> status = new ArrayList<String>();
		status.add("inserted");

		return status;
	}
}
