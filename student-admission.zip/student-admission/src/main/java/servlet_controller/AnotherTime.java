package servlet_controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;

public class AnotherTime {

	public void next(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		ArrayList<String> details = new ArrayList<String>();
		details.add(req.getParameter("name"));
		if (ClientBuilder.newClient().target("http://localhost:8082/student-admission/webapi/another_time")
				.request(MediaType.APPLICATION_JSON).post(Entity.entity(details, MediaType.APPLICATION_JSON))
				.getStatus() == 200) {
			resp.sendRedirect("newadmissionform.jsp");
		}
	}

}
