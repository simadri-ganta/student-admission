package business_logic;

import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

public class Registeration {


	public String register(HttpServletRequest req) {
		System.out.println("coming registeration");
		ArrayList<String> details = new ArrayList<String>();
		details.add(req.getParameter("name"));
		details.add(req.getParameter("board"));
		details.add(req.getParameter("marks"));
		if(req.getParameter("board").contentEquals("ssc")) {
			int gpa=Integer.parseInt(req.getParameter("marks"))/100;
			details.add(String.valueOf(gpa));
		}else {
			details.add(req.getParameter("gpa"));
		}
		details.add(req.getParameter("percentage"));
		details.add(req.getParameter("school"));
		details.add(req.getParameter("department"));
		details.add(req.getParameter("college1"));
		details.add(req.getParameter("college2"));
		
		
		Client client =ClientBuilder.newClient();
		WebTarget webTarget = client.target("http://localhost:8082/student-admission/webapi/new_registeration");
		
		String status=webTarget.request().post(Entity.entity(details,MediaType.APPLICATION_JSON)).readEntity(String.class);
System.out.println(status);
		return status;
	}

}
